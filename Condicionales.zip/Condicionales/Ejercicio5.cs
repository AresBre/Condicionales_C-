﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/*
namespace Condicionales
{
    internal class Ejercicio5
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ingrese los cinco resultados de las notas de 0,0 a 5,0: ");
            Double not1 = Convert.ToDouble(Console.ReadLine());
            Double not2 = Convert.ToDouble(Console.ReadLine());
            Double not3 = Convert.ToDouble(Console.ReadLine());
            Double not4 = Convert.ToDouble(Console.ReadLine());
            Double not5 = Convert.ToDouble(Console.ReadLine());

            Double[] op = {not1, not2, not3, not4, not5}; 

            Double resul = op.Average();

            if (resul >= 3) {
                Console.WriteLine("Felicidades usted aprobo con: " + resul);
            }
            else
            {
                Console.WriteLine("No aprobo: "+ resul);
            }

        }
    }
}
*/