﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/*
namespace Condicionales
{
    internal class Ejercicio11
    {
        static void Main(string[] args)
        {
                Console.WriteLine("Selecciona el tamaño de la pizza (1, 2 o 3):");
                int tamaño = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("Introduce el número de ingredientes adicionales:");
                int numIngredientes = Convert.ToInt32(Console.ReadLine());

                int precioBase;

                switch (tamaño)
                {
                    case 1:
                        precioBase = 15000;
                        break;
                    case 2:
                        precioBase = 24000;
                        break;
                    case 3:
                        precioBase = 36000;
                        break;
                    default:
                        Console.WriteLine("Tamaño no válido.");
                        return;
                }

                int precioIngredientes = numIngredientes * 4000;
                int precioTotal = precioBase + precioIngredientes;

                Console.WriteLine("El precio total de la pizza es: $" + precioTotal);
        }
    }
}
*/