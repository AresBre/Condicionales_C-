﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/*
namespace Condicionales
{
    internal class Ejercicio4
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ingrese dos numeros");
            int num1 = Convert.ToInt32(Console.ReadLine());
            int num2 = Convert.ToInt32(Console.ReadLine());

            int resul = Math.Max(num1, num2);

            Console.WriteLine("El numero mayor es: "+ resul);

        }

    }
}
*/