﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/*
namespace Condicionales
{
    internal class Ejercicio8
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Introduce el primer numero:");
            int num1 = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Introduce el segundo numero:");
            int num2 = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Introduce el tercer numero:");
            int num3 = Convert.ToInt32(Console.ReadLine());

            int temp;
            if (num1 > num2)
            {
                temp = num1;
                num1 = num2;
                num2 = temp;
            }
            if (num1 > num3)
            {
                temp = num1;
                num1 = num3;
                num3 = temp;
            }
            if (num2 > num3)
            {
                temp = num2;
                num2 = num3;
                num3 = temp;
            }
            Console.WriteLine("Numeros en orden ascendente:");
            Console.WriteLine(num1 + ", " + num2 + ", " + num3);

            Console.WriteLine("Numeros en orden descendente:");
            Console.WriteLine(num3 + ", " + num2 + ", " + num1);

        }
    }
}
*/