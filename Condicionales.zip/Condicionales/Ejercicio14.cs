﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/*
namespace Condicionales
{
    internal class Ejercicio14
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Introduce la edad:");
            int edad = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Introduce el género (1 para femenino, 2 para masculino):");
            int genero = Convert.ToInt32(Console.ReadLine());

            decimal pulsaciones;

            if (genero == 1)
            {
                pulsaciones = (220 - edad) / 10m;
            }
            else if (genero == 2)
            {
                pulsaciones = (210 - edad) / 10m;
            }
            else
            {
                Console.WriteLine("Género no válido.");
                return;
            }

            Console.WriteLine("El número de pulsaciones por cada 10 segundos de ejercicio es: "+ pulsaciones);
        }
    }
}
*/