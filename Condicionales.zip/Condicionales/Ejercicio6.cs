﻿using System;

/*
namespace Condicionales
{
    internal class Ejercicio6
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ingrese un numero segun el area que desea: ");
            Console.WriteLine("1. Rectangulo");
            Console.WriteLine("2. Cuadrado");
            Console.WriteLine("3. Paralelogramo");
            Console.WriteLine("4. Rombo");
            Console.WriteLine("5. Trapecio");
            Console.WriteLine("6. Triangulo");
            Console.WriteLine("7. Triangulo equilatero");
            Console.WriteLine("8. Triangulo rectagulo");
            Console.WriteLine("9. Poligono regular");
            
            int opt = Convert.ToInt32(Console.ReadLine());

            switch (opt)
            {
                case 1:
                    Console.WriteLine("Ingrese la altura");
                    int a1 = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Ingrese la base");
                    int b1 = Convert.ToInt32(Console.ReadLine());

                    int resul1 = a1 * b1;
                    Console.WriteLine("El area del rectangulo es de: "+ resul1);
                    break;

                case 2:
                    Console.WriteLine("Ingrese un lado");
                    int l = Convert.ToInt32(Console.ReadLine());
                    
                    int resul2 = l * l;
                    Console.WriteLine("El area del cuadrado es de: " + resul2);
                    break;

                case 3:
                    Console.WriteLine("Ingrese la altura");
                    int a2 = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Ingrese la base");
                    int b2 = Convert.ToInt32(Console.ReadLine());

                    int resul3 = a2 * b2;
                    Console.WriteLine("El area del paralelogramo es de: " + resul3);
                    break;

                case 4:
                    Console.WriteLine("Ingrese la diagonal mayor");
                    int D = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Ingrese la diagonal menor");
                    int d = Convert.ToInt32(Console.ReadLine());

                    int resul4 = (D * d) / 2;
                    Console.WriteLine("El area del rombo es de: " + resul4);
                    break;

                case 5:
                    Console.WriteLine("Ingrese la base mas pequeña");
                    int a3 = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Ingrese la base mas grande");
                    int b3 = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Ingrese la altura");
                    int h3 = Convert.ToInt32(Console.ReadLine());

                    int resul5 = ((a3 + b3) / 2)* h3;
                    Console.WriteLine("El area del trapecio es de: "+ resul5);
                    break;

                case 6:
                    Console.WriteLine("Ingrese la altura");
                    int a4 = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Ingrese la base");
                    int b4 = Convert.ToInt32(Console.ReadLine());

                    int resul6 = (a4 * b4)/ 2;
                    Console.WriteLine("El area del triangulo es de: " + resul6);
                    break;

                case 7:
                    Console.WriteLine("Ingrese un lado del triangulo");
                    int a5 = Convert.ToInt32(Console.ReadLine());

                    double resul7 = ((Math.Pow(a5, 2))*(Math.Sqrt(3)))/ 4;
                    Console.WriteLine("El area del triangulo equilatero es: "+ resul7);
                    break;

                case 8:
                    Console.WriteLine("Ingrese la altura");
                    int a6 = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Ingrese la base");
                    int b6 = Convert.ToInt32(Console.ReadLine());

                    int resul8 = (a6 * b6)/ 2;
                    Console.WriteLine("El area del triangulo equilatero es: " + resul8);
                    break;

                case 9:
                    Console.WriteLine("Ingrese la longitud del apotema");
                    int ap = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Ingrese el perimetro del poligono");
                    int p = Convert.ToInt32(Console.ReadLine());

                    int resul9 = (p * ap)/ 2;
                    Console.WriteLine("El area del triangulo equilatero es: " + resul9);
                    break;
            }

        }

    }
}
*/