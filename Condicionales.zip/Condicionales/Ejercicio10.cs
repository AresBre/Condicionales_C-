﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/*
namespace Condicionales
{
    internal class Ejercicio10
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Introduce el numero de llantas:");
            int numLlantas = Convert.ToInt32(Console.ReadLine());

            decimal precioUnitario;

            if (numLlantas < 6)
            {
                precioUnitario = 240000m;
            }
            else if (numLlantas <= 7)
            {
                precioUnitario = 221000m;
            }
            else
            {
                precioUnitario = 180000m;
            }

            decimal valorTotal = numLlantas * precioUnitario;

            Console.WriteLine("El valor total de la compra es: " + valorTotal);
        }
    }
}
*/