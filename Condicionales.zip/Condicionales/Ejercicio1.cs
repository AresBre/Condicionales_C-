﻿using System.ComponentModel.Design;
using static System.Runtime.InteropServices.JavaScript.JSType;

/*
namespace Condicionales
{
    internal class Ejercicio1
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ingrese un numero");
            int num = Convert.ToInt32(Console.ReadLine());

            if (num % 2 == 0)
            {
                Console.WriteLine("El numero es par");
            }
            else if (num == 0)
            {
                Console.WriteLine("El numero es cero");
            }
            else
            {
                Console.WriteLine("El numero es impar");
            }
        }
    }
}
*/