﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/*
namespace Condicionales
{
    internal class Ejercicio13
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Introduce el peso en kilogramos:");
            decimal peso = Convert.ToDecimal(Console.ReadLine());

            Console.WriteLine("Introduce la estatura en metros:");
            decimal estatura = Convert.ToDecimal(Console.ReadLine());

            decimal imc = peso / (estatura * estatura);
            string estado;

            if (imc < 18.5m)
            {
                estado = "Desnutrido";
            }
            else if (imc < 25m)
            {
                estado = "Normal";
            }
            else if (imc < 30m)
            {
                estado = "Sobrepeso";
            }
            else if (imc < 35m)
            {
                estado = "Obesidad Grado 1";
            }
            else if (imc < 40m)
            {
                estado = "Obesidad Grado 2";
            }
            else if (imc < 50m)
            {
                estado = "Obesidad Grado 3";
            }
            else
            {
                estado = "Obesidad Grado 4";
            }

            Console.WriteLine("El IMC es: " + imc);
            Console.WriteLine("Estado: "+ estado);
        }
    }
}
*/