﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/*
namespace Condicionales
{
    internal class Ejercicio7
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Seleccione una opción de conversión:");
            Console.WriteLine("1. Fahrenheit a Celsius");
            Console.WriteLine("2. Fahrenheit a Kelvin");
            Console.WriteLine("3. Fahrenheit a Rankine");
            Console.WriteLine("4. Fahrenheit a Réaumur");
            Console.WriteLine("5. Celsius a Fahrenheit");
            Console.WriteLine("6. Celsius a Kelvin");
            Console.WriteLine("7. Celsius a Rankine");
            Console.WriteLine("8. Celsius a Réaumur");
            Console.WriteLine("9. Kelvin a Celsius");
            Console.WriteLine("10. Kelvin a Fahrenheit");
            Console.WriteLine("11. Kelvin a Rankine");
            Console.WriteLine("12. Kelvin a Réaumur");
            Console.WriteLine("13. Rankine a Celsius");
            Console.WriteLine("14. Rankine a Fahrenheit");
            Console.WriteLine("15. Rankine a Kelvin");
            Console.WriteLine("16. Rankine a Réaumur");
            Console.WriteLine("17. Réaumur a Celsius");
            Console.WriteLine("18. Réaumur a Fahrenheit");
            Console.WriteLine("19. Réaumur a Kelvin");
            Console.WriteLine("20. Réaumur a Rankine");

            int opcion = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Introduce la temperatura:");
            double temperatura = Convert.ToDouble(Console.ReadLine());

            double resultado;

            switch (opcion)
            {
                case 1:
                    resultado = (temperatura - 32) / 1.8;
                    Console.WriteLine("La temperatura en Celsius es: " + resultado);
                    break;
                case 2:
                    resultado = (temperatura + 459.67) / 1.8;
                    Console.WriteLine("La temperatura en Kelvin es: " + resultado);
                    break;
                case 3:
                    resultado = temperatura + 459.67;
                    Console.WriteLine("La temperatura en Rankine es: " + resultado);
                    break;
                case 4:
                    resultado = (temperatura - 32) / 2.25;
                    Console.WriteLine("La temperatura en Réaumur es: " + resultado);
                    break;
                case 5:
                    resultado = temperatura * 1.8 + 32;
                    Console.WriteLine("La temperatura en Fahrenheit es: " + resultado);
                    break;
                case 6:
                    resultado = temperatura + 273.15;
                    Console.WriteLine("La temperatura en Kelvin es: " + resultado);
                    break;
                case 7:
                    resultado = temperatura * 1.8 + 32 + 459.67;
                    Console.WriteLine("La temperatura en Rankine es: " + resultado);
                    break;
                case 8:
                    resultado = temperatura * 0.8;
                    Console.WriteLine("La temperatura en Réaumur es: " + resultado);
                    break;
                case 9:
                    resultado = temperatura - 273.15;
                    Console.WriteLine("La temperatura en Celsius es: " + resultado);
                    break;
                case 10:
                    resultado = temperatura * 1.8 - 459.67;
                    Console.WriteLine("La temperatura en Fahrenheit es: " + resultado);
                    break;
                case 11:
                    resultado = temperatura * 1.8;
                    Console.WriteLine("La temperatura en Rankine es: " + resultado);
                    break;
                case 12:
                    resultado = (temperatura - 273.15) * 0.8;
                    Console.WriteLine("La temperatura en Réaumur es: " + resultado);
                    break;
                case 13:
                    resultado = (temperatura - 32 - 459.67) / 1.8;
                    Console.WriteLine("La temperatura en Celsius es: " + resultado);
                    break;
                case 14:
                    resultado = temperatura - 459.67;
                    Console.WriteLine("La temperatura en Fahrenheit es: " + resultado);
                    break;
                case 15:
                    resultado = temperatura / 1.8;
                    Console.WriteLine("La temperatura en Kelvin es: " + resultado);
                    break;
                case 16:
                    resultado = (temperatura - 32 - 459.67) / 2.25;
                    Console.WriteLine("La temperatura en Réaumur es: " + resultado);
                    break;
                case 17:
                    resultado = temperatura / 0.8;
                    Console.WriteLine("La temperatura en Celsius es: " + resultado);
                    break;
                case 18:
                    resultado = temperatura * 2.25 + 32;
                    Console.WriteLine("La temperatura en Fahrenheit es: " + resultado);
                    break;
                case 19:
                    resultado = temperatura / 0.8 + 273.15;
                    Console.WriteLine("La temperatura en Kelvin es: " + resultado);
                    break;
                case 20:
                    resultado = temperatura * 2.25 + 32 + 459.67;
                    Console.WriteLine("La temperatura en Rankine es: " + resultado);
                    break;
                default:
                    Console.WriteLine("Opción no válida.");
                    break;
            }
        }
    }
}
*/