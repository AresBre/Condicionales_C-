﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/*
namespace Condicionales
{
    internal class Ejercicio2
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ingrese su nombre");
            String nombre = Console.ReadLine();

            Console.WriteLine("Ingrese su edad");
            int edad = Convert.ToInt32(Console.ReadLine());

            if (edad >= 100 | edad < 0)
            {
                Console.WriteLine("Ingrese una edad valida");
            }
            else if (edad >= 18)
            {
                Console.WriteLine("Usted es mayor de edad");
            }
            else
            {
                Console.WriteLine("Usted es menor de edad");
            }
        }
    }
}
*/