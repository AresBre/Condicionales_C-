﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/*
namespace Condicionales
{
    internal class Ejercicio12
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Introduce la cantidad de articulos:");
            int cantidad = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Introduce el precio unitario original:");
            decimal precioUnitario = Convert.ToDecimal(Console.ReadLine());

            decimal descuento = 0m;

            if (cantidad > 5 && cantidad < 10)
            {
                descuento = 0.05m; // 5% de descuento
            }
            else if (cantidad >= 10)
            {
                descuento = 0.08m; // 8% de descuento
            }

            decimal precioConDescuento = precioUnitario * (1 - descuento);
            decimal valorTotal = precioConDescuento * cantidad;

            Console.WriteLine("El valor total a pagar es: $" + valorTotal);
        }
    }
}
*/