﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/*
namespace Condicionales
{
    internal class Ejercicio9
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Introduce el monto de la cuenta:");
            decimal monto = Convert.ToDecimal(Console.ReadLine());

            string metodoPago;

            if (monto < 150000)
            {
                metodoPago = "en efectivo";
            }
            else if (monto <= 300000)
            {
                metodoPago = "con el celular (dinero electronico)";
            }
            else if (monto <= 600000)
            {
                metodoPago = "con la tarjeta de debito";
            }
            else
            {
                metodoPago = "con la tarjeta de credito";
            }

            Console.WriteLine("El método de pago recomendado es: " + metodoPago);
        }
    }
}
*/